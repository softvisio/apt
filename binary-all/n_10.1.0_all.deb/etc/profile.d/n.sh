#!/bin/sh

export N_PREFIX=/usr/n

NPM_PREFIX=$(realpath ~)/.npm/bin

[[ :$PATH: == *":$NPM_PREFIX:"* ]] || PATH="$NPM_PREFIX:$PATH"

[[ :$PATH: == *":$N_PREFIX/bin:"* ]] || PATH+=":$N_PREFIX/bin"
